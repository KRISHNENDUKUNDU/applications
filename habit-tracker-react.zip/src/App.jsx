import React, { useEffect, useState } from "react";

function App() {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch("/data/habits.json")
      .then((res) => res.json())
      .then((json) => setData(json))
      .catch((err) => console.error("Failed to load JSON:", err));
  }, []);

  if (!data) {
    return <div style={{ padding: 40 }}>Loading dashboard...</div>;
  }

  return (
    <div style={{ padding: 24, fontFamily: "Arial, sans-serif", background: "#f8fafc" }}>
      <div style={{ background: "#e9d5ff", padding: 24, borderRadius: 16, marginBottom: 20 }}>
        <h1>{data.title}</h1>
        <p>{data.month} {data.year}</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20 }}>
        <div style={{ background: "#fff", padding: 20, borderRadius: 16 }}>
          <h2>Top Habits</h2>
          <ol>
            {data.topHabits.map((habit, i) => (
              <li key={i} style={{ marginBottom: 8 }}>{habit}</li>
            ))}
          </ol>
        </div>

        <div style={{ background: "#fff", padding: 20, borderRadius: 16 }}>
          <h2>Progress</h2>
          {data.progress.map((item, i) => (
            <div key={i} style={{ marginBottom: 16 }}>
              <p>{item.name} - {item.percent}%</p>
              <div style={{ background: "#e5e7eb", height: 12, borderRadius: 999 }}>
                <div
                  style={{
                    width: `${item.percent}%`,
                    height: "100%",
                    background: "#86efac",
                    borderRadius: 999
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;
