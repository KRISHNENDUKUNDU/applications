# food
Food order app (Ionic 3 / Angular 4)


# STARTUP
- install ionic `npm install -g ionic@latest`
- install cordova `npm install -g cordova`
- install dependencies `npm install`

# Lauch project
- `ionic serve -l`
- use ionic emulator on web browser

# Emulate project on Android
- install android emulator API 25(max) via Android Studio
- `ionic cordova android run`
